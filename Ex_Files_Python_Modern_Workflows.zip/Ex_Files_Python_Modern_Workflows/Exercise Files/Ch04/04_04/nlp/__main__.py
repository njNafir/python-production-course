"""Allow running nlp with python -m"""

from nlp import httpd

# TODO: Command line
if __name__ == '__main__':
    httpd.main()
