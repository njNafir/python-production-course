"""Logging to stderr"""

import logging


def hello():
    logging.info('Roses are red')


if __name__ == '__main__':
    hello()
